use csc411_image::{Read, GrayImage};
use std::env;
 
fn main() {
    let input = env::args().nth(1);
    let img = GrayImage::read(input.as_deref()).unwrap();
    let denom = img.denominator as u64;
    let mut total = 0.000;
    assert!(env::args().nth(2) == None, "More than one argument is present");
 
    let count = img.pixels.len() as f64;

    // For every pixel we come across in img, pixel_num 
    // will store the value of the pixel.
    // converted_num will equal our previously defined
    // pixel_num as a float of 64 bits and divided by
    // the denominator given by the image we receive
    // Total will take in converted_num and divide by
    // count (the img.pixels total length) giving us
    // our average.
    for pixel in img.pixels {
        let pixel_num = pixel.value;
        let converted_num = pixel_num as f64/denom as f64;
        total = total + converted_num;
    }
    println!("{:.3}" ,(((total/count) * 1000.000).round())/1000.000);
}
