Names: Isabella Martinez and Noah Santagata

We have gone to Connor/Andrew's ta hours several times throughout the development of our code, 
asking about syntax errors/minor code improvements. Additionally, we both have contributed
to this code in the presence of one another whether in person or over discord. For online resources,
we heavily used https://www.rust-lang.org/ to help us understand how to use the datastructures we 
implemented as well as other functions/methods. 

What has been correctly implemented:
- brightness is able to read from a portable graymap file by using the CSC411_image crate provided
- brightness is able to read from standard output when no argument is given
- brightness halts with an error message if more than one argument is given
- brightness halts with an error message if a portable graymap is promised but not delivered
- brightness is able to print the average brightness of the input 
- fgroups is able to identify groups of names that share a fingerprint
- fgroups is able to print out the names of fingerprints which are associated with two or more names
- fgroups does not print out the names of fingerprints associated with exactly one name
- fgroups is able to discard badly formed/invalid input lines
- fgroups does not crash or commit memory errors if a name appears more than once
- fgroups is able to print multiple fingerprint groups, separated by newlines

What has not been correctly implemented:
- Large input is a failing test case in gradescope. Our program is producing a much bigger output than 
  gradescope expects. It seems we have the same code in the beginning of our output, yet it goes on to continue
  for longer.  

With a fully functioning, more elaborate “Fingerprint Groups” program, we are able to assign names 
to a specific value/key. While the name suggests that this code is only good for storing fingerprints 
with their corresponding group of people, it is capable of doing so much more.

A more thorough implementation of our code could be able to be used as a database checker for a concert. 
If someone purchased their ticket, their name would be marked and sent to the “Purchased," or "PurchasedVIP" category. 
In return, by using the system implementing our code, the ticketing staff would be able to let people 
in by seeing if they’re a part of the proper group. Another instance of this code can be seen in some 
sort of software/app showing positions at a workplace. Rather than the "fingerprints" key, this can be replaced as
“Cooking Station,"  “Register," “Shipping," etc, helping associates know the role the will be taking for the day, 
and who they are working alongside. Additionally, this code can would help in an online shopping store scenario. When a
user is browsing through items, they may want to filter out specific characteristics like size, color, or price range. 
This implementation can help show which items belong to the category they want to explicitly see. Additionally, if the item stock 
was below a certain threshold(like how in fgroups going below the threshold of one name warrented no printing), it could display 
"low inventory, buy soon!" to the user.

We have spent approximately 40 hours for this assignment. 

