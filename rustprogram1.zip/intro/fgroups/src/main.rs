use std::collections::HashMap;
use std::io::{self, BufRead};

// Function prt_groups inputs the groups hashmap
// and evaluates the key/value in an iterating groups
// If the length of the name vector is greater than 1
// It will print out the names in that vector, otherwise 
// it will be skipped from printing
fn prt_groups(fgroups: &mut HashMap<String, Vec<String>>){
    let mut state = "";
    for(_key, val) in fgroups.iter(){
        print!("{}", state);
        if val.len()>1{
            for entry in val{
                println!("{}", entry);
            }
            state = "\n"; 
        }
    }
}

// Function load_hash_map implements the read fingerprint and name to the hash map. 
// First, it is checked to be valid input. If it is, it goes through the match
// operator to check if the fingerprint is already stored in the hashmap and 
// adds the needed data to memory.
fn load_hash_map(fingerprint: String, name: &str, fgroups: &mut HashMap<String, Vec<String>>, _names: &mut Vec<String>){
    let mut namemut = name;
    if fingerprint.len() > 512{
        eprintln!("Error: Fingerprint length too long");
        return;
    }
    if namemut.len() < 1{
        eprintln!("Error: Missing Name");
        return;
    }
    if namemut.len() > 0 && fingerprint.len() < 1 {
        eprintln!("Error: Missing Fingerprint");
        return;
    }
    if namemut.len() > 1000 {
        eprintln!("Error: Name length too long, value truncated");
        namemut = &namemut[0..1000];
    }
    match fgroups.get_mut(&fingerprint) {
        None => {
            fgroups.insert(fingerprint.to_string(), vec![namemut.trim().to_string()]);
        }
        Some(_names) => {
            _names.push(namemut.trim().to_string());
        }
    }
    
}

// main function that creates our “fgroups” hash map which will
// properly store our fingerprints and names accordingly. 
// From here, we can also print out the appropriate names by calling
// our prt_groups
fn main() {
    let mut fgroups: HashMap<String, Vec<String>> = HashMap::new();
    let mut _names: Vec<String> = Vec::new();
    // For every fingerprint read it exists as a key in the HashMap, conversely 
    // every fingerprint that does not appear in input will never exist as keys in HashMap
    // For every name read it exists as a string in the vector/value parameter in the HashMap.
    // For every fingerprint read, the collection of names that have been read are 
    // stored as strings in a vector/value that corresponds to that fingerprint key
    for line in io::stdin().lock().lines() {
        if line.as_ref().unwrap().to_string().is_empty(){
            eprintln!("Error: Blank line");
        }
        if !line.as_ref().unwrap().to_string().contains(" "){
            eprintln!("Error: Missing Name");
        }
        else{
            let mut parts = line.as_ref().unwrap().splitn(2, ' ');
            let fingerprint = parts.next().unwrap().to_string();
            let name = parts.next().unwrap();
            load_hash_map(fingerprint, name, &mut fgroups, &mut _names); 
        }
       
    }
    prt_groups(&mut fgroups);
    
}