//A two dimensional array is being represented here through using a single Vec<T>
pub struct Array2<T>{
    pub vec_of_val:Vec<T>,
    pub width: usize,
    pub height: usize,
}

impl<T> Array2<T>{
    /// Returns an initailized 2D array
    /// 
    /// # Arguments
    /// 
    /// 'vec_of_val' - stores the actual value that will fill the 2D array
    /// can be of any type needed, though u32 will be the most commonly used
    /// 
    /// 'width' - defines the width of the 2d array
    /// 
    /// 'height' - defines the height of the 2d array
    pub fn new_array(array: Vec<T>, width: usize, height: usize) -> Self{
        Array2{
            vec_of_val: array,
            width,
            height,
        }
    }

    /// Function to iterate through our 2D array data structure in row major order
    /// Invariant: 
    /// The relationship between its position in a 2d vector and its position in a 1d vector is as follows: 
    /// The position in the 1d vector % the width of the 2d vector is the x coordinate. 
    /// The position in the 1d vector / the width of the 2d vector is the y coordinate.
    pub fn iter_row_major(&self)-> impl Iterator<Item = (usize, usize, &T)>{
        self.vec_of_val
        .iter()
        .enumerate()
        .map(move |(pos, value)| (pos % self.width, pos / self.width, value))
    }

    /// Function to iterate through our 2D array data structure in col major order
    /// Invariant:
    /// iterate for as long as our width. We then map and move our positioned element, 
    /// iterating through our vec_of_val, and skipping over the particular element we have obtained.
    /// This gives us our map of elements. By using flat_map, are we able to move based
    /// on our now sectioned element and col, of which we step through our col by the iterators 
    /// width so we know we are on the next row to get our next element of. Then we can enumerate to 
    /// pull the total amount of positions, and then move the value of row and val, based on element, 
    /// row, and val.
    pub fn iter_col_major(&self)-> impl Iterator<Item = (usize, usize, &T)>{
        (0..self.width).map(move|element| (element, self.vec_of_val.iter().skip(element)))
        .flat_map(move |(element,col)| {
            col.step_by(self.width)
                .enumerate()
                .map(move |(row,val)| (element,row,val))
        })
    }

    /// Returns value of a given row and position number in the 
    /// 2D array
    /// 
    /// # Arguments 
    /// '_row' - is the row position of the desired element
    /// 
    /// '_col' is the column position of the desired element
    pub fn get_element(&self, _row: usize, _col: usize)  -> &T{
        &self.vec_of_val[(_row * self.height + _col) as usize]
    }

}