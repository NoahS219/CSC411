use csc411_image::{Read, GrayImage};
use std::env;
pub use array2::Array2;

fn main() {
    let input = env::args().nth(1);
    let puzzle = GrayImage::read(input.as_deref()).unwrap();

    // creates a vector to use in 2darray 
    let mut v = Vec::new();

    // handles when input numbers are not between 1 and 9
    if puzzle.width != 9 || puzzle.height != 9{
        std::process::exit(1);
    }

    // loads values into 1d vector to use in our 2d array
    for elements in puzzle.pixels{
        if elements.value <= 9 && elements.value > 0{
            v.push(elements.value as usize);
        }
        else{
            std::process::exit(1);
        }
    }

    let sgrid = Array2::new_array(v, 9, 9);

    // The elements in row_iter are loaded in row major order
    // Invariant:
    // During row major iteration, the elements accessed first will be the “x” variants of the matrix we
    // have created, this being the elements in the matrix that move from left to right. Upon reaching
    // at the end of the line, this will repeat onto the next row.
    let row_iter: Vec<_> = sgrid.iter_row_major().collect();

    // The elements in row_iter are loaded in col major order
    // Invariant:
    // For column major iteration, the elements accessed first will be the “y” variants, essentially the
    // elements in the column matrix that move from top to bottom. Upon reaching the bottom of the
    // column, this will repeat at the top of the next column.
    let col_iter: Vec<_> = sgrid.iter_col_major().collect();

    let mut rowpos = 0;
    let mut colpos = 0;

    let mut row_val = Vec::new();
    for _value in &row_iter{
        row_val.push(&row_iter[rowpos].2);
        rowpos = rowpos + 1;
    }

    let mut col_val = Vec::new();
    for _value in &col_iter{
        col_val.push(&col_iter[colpos].2);
        colpos = colpos + 1;
    }

    for row_check in row_val.chunks(9) {

        // Checks if any duplicates found within the rows 
        let is_duplicate = (1..row_check.len()).any(|i| row_check[i..].contains(&row_check[i - 1]));

        if is_duplicate == true{
            std::process::exit(1);
        }
    }

    for col_check in col_val.chunks(9) {

        // Checks if any duplicates found within the cols
        let is_duplicate = (1..col_check.len()).any(|i| col_check[i..].contains(&col_check[i - 1]));

        if is_duplicate == true{
            std::process::exit(1);
        }
    }


    // Checks if any duplicates found within the 3x3 boxes  
    for row in (0..9).step_by(3){
        for col in (0..9).step_by(3){
            let mut sqbox: Vec<usize> = Vec::new();
            for roblox in 0..3{
                for coblox in 0..3{
                    // Invariant: In order to find the value of a given row and column element, the value will be 
                    // in the 1d row major vector at rowpos * height + colpos. 
                    let value = sgrid.get_element(row + roblox as usize, col + coblox as usize);
                    sqbox.push(*value);
                    
                }
            }
            for box_check in sqbox.chunks(9){
                let is_duplicate_box = (1..box_check.len()).any(|i| box_check[i..].contains(&box_check[i - 1]));
                if is_duplicate_box {
                    std::process::exit(1);
                }
            }
            sqbox.clear();
        }
    }    

}
