Names: Isabella Martinez and Noah Santagata

We went to Isaac's as well as Daniels' help hours for this assignment. 
Additionally, we both have contributed to this assignment in the presence of 
one another whether it be in person or over discord. We have also used 
doc.rust-lang.org to become more familiar with data structures and different 
operations that helped us complete this assignment. Stack Overflow was also a 
good resource in checking how to set up our own lib.rs. 

What has been correctly implemented:
- lib.rs successfully creates our own data structure representing a two-dimensional 
polymorphic array through a single Vec<T>
- lib.rs includes both a row major iterator and a col major iterator on our 2d array
- lib.rs includes the “.get_element” function where given a row and a column position, 
the value at that position in the 2d array will be returned.  
- sudoku is able to read in a graymap file or standard input
- sudoku exit codes 1 when there is a duplicate number in a row 
- sudoku exit codes 1 when there is a duplicate number in a column
- sudoku exit codes 1 when there is a duplicate number in a box 
- sudoku exit codes 1 when a number in the solution is greater than 9 or less than 1
- sudoku exit codes 0 when the input sudoku solution is correct

What has not been correctly implemented:
- Sudoku does not handle error checking for if the input dimensions were not
that of sudoku requirements (ie if there are not 9 rows and 9 columns). 

1. [*] What is the abstract thing you are trying to represent? 

    We are trying to represent a polymorphic 2D array called Array2. This will be 
    represented through a single Vec<T> with a width and height. 

2. What functions will you offer, and what are the contracts of that those
functions must meet?

    new_array(array: Vec<T>, width: usize, height: usize) is a constructor method which 
    assembles a new 2d array. It takes in an initialized single vector, a width, and a 
    height. The contract of this method is that the vector loaded must already have values 
    which need to be sorted in either row major order or column major order. Therefore, 
    objects made through this constructor will be able to call our other iterative functions 
    and get_element. 

    iter_row_major(&self) is a method on our Array2. It visits every element of the first 
    row from left to right, followed by every element in the next row below from left to 
    right and so on. This function returns an iterator that can be used to assign values 
    of a row major ordered vector. Its contract includes the need to iterate through a 
    non-empty single vector<T> to produce a row major order iterator. 

    iter_col_major(&self) is a method on our Array2. It visits every element of the first 
    column on the left from top to bottom, followed by every element in the next column 
    from top to bottom and so on. This function returns an iterator that can be used to 
    assign values of a column major ordered vector. Its contract includes the need to 
    iterate through a non-empty single vector<T> to produce a column major order iterator.

    get_element(&self, _row: usize, _col: usize) is a method on our Array2. Its 
    functionality is to return the value of an element at a given position. It performs 
    this by multiplying the row position with the height of the iterator, and then adding 
    the column position to it, all based on the elements from the single vec in Array2. 
    The precondition of this function is that the coordinates given are within the
    bounds of the 2D array.

    In our sudoku program, while we put everything in main and did not explicitly have 
    functions, there are a few lines of code that with further optimization of our code, 
    could be functions:

    check_row would include lines 50-58. This is a for loop that iterates through our 
    row_val vector that is already in row major order thanks to our iter_row_major 
    function. The purpose of these lines of code is to validate that none of the rows 
    make the sudoku solution an invalid one. We do this through checking if any of the 
    values in a single row have a duplicate number. If there is, we immediately exit 
    code 1

    check_col includes lines 60-68. Similar to checking rows, this includes a for loop 
    that iterates through a previously sorted col-major vector. The purpose of these lines
    is to check that no column invalidates the sudoku solution. It does so by having a 
    boolean that checks if a single column has a duplicate number. If it does, it immediately 
    exits through code 1. 

    check_box includes lines 72-92. This is to verify that no 3x3 box inside the sudoku p
    uzzle includes a duplicate number which would make the given solution invalid. If 
    there is a duplicate number in a box, it will give exit code 1. 

4. What representation will you use, and what invariants will it satisfy? 

    The representation we have used to implement an Array2(a polymorphic 2D array) was 
    through using a single vector which placed its values strategically to reflect a 2D 
    grid. 

    For iterating through the single vector in row_major order, we know that the relationship 
    between its position in a 2d vector and its position in a 1d vector is as follows: 
    The position in the 1d vector % the width of the 2d vector is the x coordinate. 
    The position in the 1d vector / the width of the 2d vector is the y coordinate.

    For iterating through the single vector in column major order, the relationship between 
    its position vs. that of a 2d vector is as follows:
    We iterate for as long as our width. We then map and move our positioned element, 
    iterating through our vec_of_val, and skipping over the particular element we have obtained.
    This gives us our map of elements. By using flat_map, are we able to move based
    on our now sectioned element and col, of which we step through our col by the iterators 
    width so we know we are on the next row to get our next element of. Then we can enumerate to 
    pull the total amount of positions, and then move the value of row and val, based on element, 
    row, and val.

    During row major iteration, the elements accessed first will be the “x” variants of the matrix we
    have created, this being the elements in the matrix that move from left to right. Upon reaching
    at the end of the line, this will repeat onto the next row.

    For column major iteration, the elements accessed first will be the “y” variants, essentially the
    elements in the column matrix that move from top to bottom. Upon reaching the bottom of the
    column, this will repeat at the top of the next column.

    For every element added, its corresponding row position and col position will be kept track of in
    Array2.

    In order to find the value of a given row and column element, the value will be in the 1d row 
    major vector at rowpos * height + colpos. 

About 32 hours were spent on this assignment.

