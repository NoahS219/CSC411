#[derive(Clone, Debug)]

/// Struct 'Registers'
/// contains 'registers' as Vec<u32>
pub struct Registers {
    registers: Vec<u32>,

}

//functions for our register structs
impl Registers {

    /// this function creates empty registers to be used
    pub fn new() -> Registers {
        Registers {
            registers: vec![0; 8],
        }
    }

    /// this function returns the value located in a given register
    ///
    /// # Arguments:
    /// * 'register' <usize> holds which register to be given the value back of 
    pub fn get_reg_val(&self, register: usize) -> u32 {
        self.registers[register]
    }

    /// this function takes in a register and value and updates the register to be the given value
    /// 
    /// # Arguments:
    /// * 'register' <usize> holds which register is going to be updated
    /// * 'value' <u32> is the value to update the register to hold
    pub fn set_reg_val(&mut self, register: usize, value: u32) {
        self.registers[register] = value
    }
}