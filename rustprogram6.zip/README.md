**Identifies you and your programming partner by name**
Isabella Martinez and Noah Santagata
 

**Acknowledges help you may have received from or collaborative work you may have undertaken with others**
Since we did not have time to go to ta hours due to studying for other finals, we used internet resources for how to use the tools to profile our code like valgrind, kcachegrind visualizer, and flamegraph. 
 
**What routine in the final um takes up the most time, and whether the assembly code could be improved and how**
In our final version of the UM, the process that takes up the most time is when we are inside of our instructions.rs module. This is because of the sheer amount of times it is called. We enter instructions.rs every time we encounter a new instruction. Our main.rs calls on instructions when matching the current instruction's enum opcode to a designated function in our rum.rs. Additionally, everytime we created an instruction, we had to load values into our op,a,b,c, and value fields inside of our Instruction struct. With the accumlation of all of these tasks, the routine that takes up the most time in our final UM is loading and getting values from our Instruction struct. This may be able to be improved through simplyfying our functions (get_opcode, get_a, get_b, get_c, and get_value functions) inside instructions.rs into one function so that they would only need to be called once, rather than called on 5 separate occassions every time we need to load an Instruction struct. This would simply the amount of times that the assembly code would need to load, store, and jump to memory. However, we thought this would be too major of a reconstruction of our code for the purposes of this assignment. 

**Says approximately how many hours you have spent analyzing the problems posed in the assignment**
We have approximately spent 4 hours analyzing the assignment.
 
**Says approximately how many hours you have spent solving the problems after your analysis**
We have approximately spent 15 hours solving the given assignment problem.

