**Identifies you and your programming partner by name**
Isabella Martinez and Noah Santagata
 

**Acknowledges help you may have received from or collaborative work you may have undertaken with others**
We have not collaborated or gotten any help from any external parties. 
 
 
**Identifies what has been correctly implemented and what has not**
As far as we know, everything has been implemented correctly. 
 
- able to execute hello.um
 
- able to execute cat.um
 
- able to execute midmark.um
 
- able to execute sandmark.um
 
- able to read in and execute all the opcode instructions
 
- able to organize the registers and segments 
 
**Briefly enumerates any significant departures from your design** 
Overall, we had a very similar implementation to the one we described in our design document, as we got a good grade and mostly followed what we mentioned in our design doc. However, some departures we can think of are the following:
 
We had more modules than we specified in our design doc since we wanted to add a module for the registers.
 
We had switched over from trying to instantiate every instance of a structure to instead reference it when using an ‘impl’, specifically through the use of &self. This is effective for being able to access the register/memory at a given moment, and to update it “on-the-fly” essentially.
 
This was effectively our only departure, otherwise we worked around and meddled with features that were sufficient in working around.

 
**Succinctly describe the architecture of your system. Identify the modules used, what abstractions they implement, what secrets they know, and how they relate to one another. Avoid narrative descriptions of the behavior of particular modules.**
Excluding main and bitpack, we have four modules. They include rum.rs, segments.rs, instructions.rs, and registers.rs. 
 
Rum.rs - this module holds the main execution for opcode. Creating functions within a rum impl, we are able to call these opcodes on the current segments and registers we have to manipulate them as needed specific to each opcode. 
 
Instructions.rs - this module processes the instructions specific with loadvalue in order to get register values and organize an instruction into its opcode, what registers a, b, and c holds, and the current value. 
 
Segements.rs - this mainly holds the logic for mapping and unmapping segments. 
 
Registers.rs - this module holds functionality for creating the register object and updating/returning register values.
 
Firstly, main reads in the um file, and calls new from rum. New creates a new object of a RUM struct, aka a compilation of register and segment structs based off of the file read in. Those segments are composed of addresses and instructions left on the heap. The registers are composed of the eight registers we have available, represented in a vector of u32. The main architecture of our main.rs logic after that is going through a loop until all the instructions from the file have been executed. We have a compilation of if/else statements to execute the corresponding opcode the instruction calls for which is located in instructions.rs. Based on that opcode, rum.rs is summoned to execute the desired opcode functionality. We also have a counter in main which gets incremented every time an instruction is processed to keep track of where we are in the grand scheme of the um file. 
 
Within rum, it will call upon ‘instructions’ and use public variables op: Opcode (stemmed from Opcode enumerator), a: u32, b: Option<u32>, c: Option<u32>, and value: Option<u32>, acting as placements for new equations to be placed into (mainly a) as well as being place-holders for other bits of information. Then, based on the given opcode found (which is obtained from running ‘getu’ within bitpack, giving the specific numbered instruction) the type of operation is selected (i.e. if the operation is 6, Nand would run, operation is 2, Store would run). This would then bring us to the applications of Rum found later within it, the calculations.

For each given instruction, it will match up to an operation found within rum. Every calculation performed is different, but still involves manipulating the public variables a, b, c, and value. While based on the calculation, it will typically access either ‘segment.rs’ or ‘register.rs’ in order to store/load and or retrieve information from the value at a given index. Within these functions are set statements that test if any outcomes are invalid. The code then concludes by returning to us the information given from the um(z) file, after being modified by our program.



**Invariants:**
The segment ID is located in a specific segment order based on when it was read.
The invariants held within our program will be each and every call that is made to the program in terms of loading and storing values, as well as the calculations performed from Opcode.rs
All segments may be mapped but not all segments may be unmapped since the first segment in memory will always contain every instruction needed.
Previously mapped segments may be reused after using the unmapsegment opcode.
 
**Explains how long it takes your UM to execute 50 million instructions, and how you know**
Our UM takes on average 8.03 seconds to execute 50 million instructions. We know this because we added a timer using std::time::Instant. Additionally, we had a counter which counted the number of instructions we have already processed to know that we hit 50,000,000. The code that we wrote to do this is still in our main, but is commented out. When the instruction count hit 50,000,000, we exited and printed out how long it took. We ran our code several times with this timer to get an accurate average of the performance of our UM. 
 

**Says approximately how many hours you have spent analyzing the assignment**
We have approximately spent 4 hours analyzing the assignment.
 
 
**Says approximately how many hours you have spent preparing your design**
We have approximately spent 8 hours preparing the design doc.
 
 
**Says approximately how many hours you have spent solving the problems after your analysis**
We have approximately spent 35 hours solving the given assignment problem.

