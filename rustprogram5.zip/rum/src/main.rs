use std::env;
use std::process;
mod rum;
mod segments;
mod registers;
mod instructions;

//use std::time::Instant;

//reads instructions from a file via command line (was included in rumdump lab)
fn read_instructions(filename: &str) -> Vec<u32> {
    
    let mut raw_reader: Box<dyn std::io::BufRead> = match Some(filename) {
        None => Box::new(std::io::BufReader::new(std::io::stdin())),
            Some(filename) => Box::new(std::io::BufReader::new(
                 std::fs::File::open(filename).unwrap(),
            )),
             };
        let mut buf = Vec::<u8>::new();
         raw_reader.read_to_end(&mut buf).unwrap();
         let instructions: Vec<u32> = buf
         .chunks_exact(4)
         .map(|x| u32::from_be_bytes(x.try_into().unwrap()))
         .collect();
         instructions
}

fn main() {
    //let _timer_boy = Instant::now();
    //reads in the filename in order to extract the instructions from the different segments
    let args: Vec<String> = env::args().collect();
    let filename = &args[1];
    //calls our read_instructions function and returns a vector of the instructions
    let instructions = read_instructions(filename);
    //new rum made using the instructions to parse through
    let mut rum = rum::Rum::new(&instructions);
    
    //counts how many instructions we have executed and processed
    let mut counter: usize = 0;
    //let mut instruction_count: usize = 0;
    

    // loops until the opcode is to hault or throws an error with a unknown opcode value
    for _i in 0..usize::MAX{
        //based on which instruction we are in, we obtain the opcode value to do its corresponding work
        let instruction = rum.get_instruction(counter);
        // incremented everytime we enter the top of the for loop as this is another instruction that we parsed through
        counter += 1;
        // instruction_count += 1;
        // if instruction_count == 50000000{
        //     println!("50000000 hit");
        //     println!("This is how long it took: {:.2?}", _timer_boy.elapsed());
        //     process::exit(0);
        // }
        
        //if and else statements for the various opcodes and an extra one for if the opcode value is not recognized
        if instruction.op == instructions::Opcode::CMov{
            rum.cmov(instruction);
        }
        else if instruction.op == instructions::Opcode::Load {
            rum.load(instruction);
        }
        else if instruction.op == instructions::Opcode::Store {
            rum.store(instruction);
        }
        else if instruction.op == instructions::Opcode::Add {
            rum.add(instruction);
        }
        else if instruction.op == instructions::Opcode::Mul {
            rum.mul(instruction);
        }
        else if instruction.op == instructions::Opcode::Div {
            rum.div(instruction);
        }
        else if instruction.op == instructions::Opcode::Nand {
            rum.nand(instruction);
        }
        else if instruction.op == instructions::Opcode::Halt {
            process::exit(0);
        }
        else if instruction.op == instructions::Opcode::MapSegment {
            rum.mapsegment(instruction);
        }
        else if instruction.op == instructions::Opcode::UnmapSegment {
            rum.unmapsegment(instruction);
        }
        else if instruction.op == instructions::Opcode::Output {
            rum.output(instruction);
        }
        else if instruction.op == instructions::Opcode::Input {
            rum.input(instruction);
        }
        else if instruction.op == instructions::Opcode::LoadProgram {
            counter = rum.loadprogram(instruction);
        }
        else if instruction.op == instructions::Opcode::LoadValue {
            rum.loadvalue(instruction);
        }
        else if instruction.op == instructions::Opcode::Err {
            panic!(
                "Unknown opcode for instruction {:?}", instruction
            )
        }
    }
}