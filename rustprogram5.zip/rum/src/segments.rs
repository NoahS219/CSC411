use std::mem;
use crate::{instructions::Instruction};

#[derive(Debug, Clone)]
pub struct Segments {
    free_addresses: Vec<usize>,
    instruc_to_do: Vec<Vec<u32>>
}

impl Segments {

    /// creates a new instance of a segment 
    /// 
    /// # Argument:
    /// * 'instructions' <&Vec<u32>> holds a vector of all the instructions from a program
    pub fn new(instructions: &Vec<u32>) -> Segments {
        Segments {
            free_addresses: Vec::new(),
            instruc_to_do: vec![instructions.to_vec()]
        }
    }

    /// This function starts off with a vector of all zeros of a specified size to check the given bit pattern. 
    /// A bit pattern that is not all zeros does not identify any currently mapped segment is placed in register b
    /// 
    /// # Arguments:
    /// * 'size' <usize> holds the size of register c to map a segment
    pub fn mapsegment(&mut self, size: usize) -> usize {
        let zeros = vec![0_u32; size];
        match self.free_addresses.len(){
            0 => {
                self.instruc_to_do.push(zeros);
                self.instruc_to_do.len() - 1
            }
            _ => {
                let address = self.free_addresses.pop().unwrap();
            let _new_add = mem::replace(self.instruc_to_do.get_mut(address).unwrap(),zeros);
            address
            }
        }
       
    }

    /// unmaps segments from register c so it can be reused in the future
    /// 
    /// # Arguments:
    /// * 'address' <usize> holds where to unsegment
    pub fn unmapsegment(&mut self, address: usize) {
        self.free_addresses.push(address);
        let _new_add = mem::replace(self.instruc_to_do.get_mut(address).unwrap(), Vec::new());
    }


    /// gets the value of the segment at a given address
    /// 
    /// # Arguments:
    /// * 'address' <usize> holds the address to get the value of 
    pub fn get(&self, address: usize) -> Option<&Vec<u32>> {
        self.instruc_to_do.get(address)
    }

    /// Returns the instruction that is found in the segment
    /// 
    /// # Arguments:
    /// * 'counter' <usize> holds where we are in the instructions 
    pub fn get_instruction(&self, counter: usize) -> Instruction {
        match self.instruc_to_do.get(0) {
            Some(seg) => Instruction::new(seg[counter]),
            None => panic!("No more instructions")
        }
    }

    /// uses the given value to write to a given address and index of a segment
    /// 
    /// # Arguments:
    /// 'address' <usize> is where to go in the memory
    /// 'index' <usize> is which index to go inside of the address
    /// 'value' <u32> is the value to store
    pub fn set_seg_val(&mut self, address: usize, index: usize, value: u32) {
        let segments = self.instruc_to_do.get_mut(address).unwrap();
        let _new_add = mem::replace(segments.get_mut(index).unwrap(),value);
    }

    /// replaces the segment with the given address segment
    /// 
    /// # Arguments:
    /// 'address' <uszie> is where to load in loadprogram
    pub fn load(&mut self, address: usize) {
        let seg = self.instruc_to_do.get(address).unwrap().clone();
        let _new_add = mem::replace(self.instruc_to_do.get_mut(0).unwrap(),seg);
    }
}