#[derive(Debug)]
//create a struct for each instruction including the opcode, registers, and value fields
pub struct Instruction {
    pub op: Opcode,
    pub a: u32,
    pub b: Option<u32>,
    pub c: Option<u32>,
    pub value: Option<u32>
}
// we use our getu from our bitpack to be able to receive values from our segements like the registers and opcode values
use bitpack::bitpack::{getu};

// made an enum for the different opcodes we could have
#[derive(Debug, PartialEq)]
pub enum Opcode {
    CMov,
    Load,
    Store,
    Add,
    Mul,
    Div,
    Nand,
    Halt,
    MapSegment,
    UnmapSegment,
    Output,
    Input,
    LoadProgram,
    LoadValue,
    Err
}

/// this function is for actually checking the value of the opcode in our different segments
/// 
/// # Arguments:
/// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
pub fn get_opcode(instruction: u32) -> Opcode {
    //opcode is located in the the last 4 bits
    let op = getu(instruction, 28, 4);

    //we have various 'if-else' statements to return which opcode is found
    if op == 0{
        Opcode::CMov
    }
    else if op == 1{
        Opcode::Load
    }
    else if op == 2{
        Opcode::Store
    }
    else if op == 3{
        Opcode::Add
    }
    else if op == 4{
        Opcode::Mul
    }
    else if op == 5{
        Opcode::Div
    }
    else if op == 6{
        Opcode::Nand
    }
    else if op == 7{
        Opcode::Halt
    }
    else if op == 8{
        Opcode::MapSegment
    }
    else if op == 9{
        Opcode::UnmapSegment
    }
    else if op == 10{
        Opcode::Output
    }
    else if op == 11{
        Opcode::Input
    }
    else if op == 12{
        Opcode::LoadProgram
    }
    else if op == 13{
        Opcode::LoadValue
    }
    else{
        Opcode::Err
    }
} 


/// The purpose of this function is to get the value that is inside the A register 
/// 
/// # Arguments:
/// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
/// * 'op' holds the value of which opcode operation is taking place
pub fn get_a(instruction: u32, op: &Opcode) -> u32 {
    if *op == Opcode::LoadValue{
        return getu(instruction, 25, 3);
    }
    else{
        return getu(instruction, 6, 3);
    }
}

/// The purpose of this function is to get the value that is inside the B register 
/// 
/// # Arguments:
/// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
/// * 'op' holds the value of which opcode operation is taking place
pub fn get_b(instruction: u32, op: &Opcode) -> Option<u32> {
    if *op == Opcode::LoadValue{
        return None;
    }
    else{
        return Some(getu(instruction, 3, 3));
    }

}

/// The purpose of this function is to get the value that is inside the C register 
/// 
/// # Arguments:
/// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
/// * 'op' holds the value of which opcode operation is taking place
pub fn get_c(instruction: u32, op: &Opcode) -> Option<u32> {
    if *op == Opcode::LoadValue{
        return None
    }
    else{
        return Some(getu(instruction, 0, 3));
    }
    
}

/// The purpose of this function is to get the value 
/// 
/// # Arguments:
/// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
/// * 'op' holds the value of which opcode operation is taking place
pub fn get_value(instruction: u32, op: &Opcode) -> Option<u32> {
    if *op == Opcode::LoadValue{
        return Some(getu(instruction, 0, 25));
    }
    else{
        return None
    }
}



//We created an impl Instruction to be able to use the functions we created above and get the values each time a new instruction is being passed
impl Instruction {
    /// creates a new instance of an 'instruction' holding values such as op, a, b, c, and value
    /// 
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn new(instruction: u32) -> Instruction {
        let op = get_opcode(instruction);
        let a = get_a(instruction, &op);
        let b = get_b(instruction, &op);
        let c = get_c(instruction, &op);
        let value = get_value(instruction, &op);

        //our instruction struct is given new values for each new segment
        Instruction {
            op,
            a,
            b,
            c,
            value
        }
    }
}