use std::io::{stdin, Read};
use crate::{registers::Registers, segments::Segments, instructions::Instruction};

#[derive(Debug, Clone)]

/// Public Struct 'Rum'
/// contains 'segment' as the value 
/// returned from the 'Segments structs'
/// 
/// contains 'registers' as the value
/// returned from the 'Register struct'
pub struct Rum {
    segment: Segments,
    registers: Registers
}

/// Implemments the struct 'Rum' as a 
/// public value within the module to use
impl Rum {


    /// creates a new segment and register for the given instructions
    /// 
    /// # Arguments:
    /// * 'instructions' holds the vector of all the instructions to parse through
    pub fn new(instructions: &Vec<u32>) -> Rum {
        Rum {
            segment: Segments::new(&instructions),
            registers: Registers::new()
        }
    }

    /// gets the instruction based on the given counter number
    /// 
    /// # Arguments:
    /// * 'counter' is the desired index of the instruction we want to return
    pub fn get_instruction(&self, counter: usize) -> Instruction {
        self.segment.get_instruction(counter)
    }

    /// assigns variables values to different segments
    /// 
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn cmov(&mut self, instruction: Instruction) {
        let a = instruction.a as usize;
        let b = instruction.b.unwrap() as usize;
        let c = instruction.c.unwrap() as usize;

        if self.registers.get_reg_val(c) != 0 {
            let value = self.registers.get_reg_val(b);
            self.registers.set_reg_val(a, value);
        }
    }

    /// loads in values to register a
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn load(&mut self, instruction: Instruction) {
        let a = instruction.a as usize;
        let b = instruction.b.unwrap() as usize;
        let c = instruction.c.unwrap() as usize;

        let address = self.registers.get_reg_val(b) as usize;
        let array = self.segment.get(address).unwrap();
        let index = self.registers.get_reg_val(c) as usize;
        let value = array[index];

        self.registers.set_reg_val(a, value);
    }

    /// stores in values for a segment
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn store(&mut self, instruction: Instruction) {
        let a = instruction.a as usize;
        let b = instruction.b.unwrap() as usize;
        let c = instruction.c.unwrap() as usize;

        let address = self.registers.get_reg_val(a) as usize;
        let index = self.registers.get_reg_val(b) as usize;
        let value = self.registers.get_reg_val(c);

        self.segment.set_seg_val(address, index, value);
    }

    /// adds values together from register b and c and stores in register a
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn add(&mut self, instruction: Instruction) {
        let a = instruction.a as usize;
        let b = instruction.b.unwrap() as usize;
        let c = instruction.c.unwrap() as usize;

        let value = self.registers.get_reg_val(b).wrapping_add(self.registers.get_reg_val(c));

        self.registers.set_reg_val(a, value);
    }

    /// multiplies values together from register b and c and stores in register a
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn mul(&mut self, instruction: Instruction) {
        let a = instruction.a as usize;
        let b = instruction.b.unwrap() as usize;
        let c = instruction.c.unwrap() as usize;

        let value = self.registers.get_reg_val(b).wrapping_mul(self.registers.get_reg_val(c));

        self.registers.set_reg_val(a, value);
    }

    /// divides values together from register b and c and stores in register a
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn div(&mut self, instruction: Instruction) {
        let a = instruction.a as usize;
        let b = instruction.b.unwrap() as usize;
        let c = instruction.c.unwrap() as usize;

        let value = self.registers.get_reg_val(b).wrapping_div(self.registers.get_reg_val(c));
        self.registers.set_reg_val(a, value);
    }

    /// performs exponential math from register b and c and stores in register a
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn nand(&mut self, instruction: Instruction) {
        let a = instruction.a as usize;
        let b = instruction.b.unwrap() as usize;
        let c = instruction.c.unwrap() as usize;

        let value = !(self.registers.get_reg_val(b) & self.registers.get_reg_val(c));

        self.registers.set_reg_val(a, value);
    }


    /// allocates a new segment of memory and stores in register b
    /// 
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn mapsegment(&mut self, instruction: Instruction) {
        let b = instruction.b.unwrap() as usize;
        let c = instruction.c.unwrap() as usize;

        let size = self.registers.get_reg_val(c) as usize;
        let address = self.segment.mapsegment(size);

        self.registers.set_reg_val(b, address as u32);
    }

    /// unmaps segments from register c so it can be reused in the future
    /// 
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn unmapsegment(&mut self, instruction: Instruction) {
        let c = instruction.c.unwrap() as usize;
        let address = self.registers.get_reg_val(c) as usize;

        self.segment.unmapsegment(address);
    }

    /// prints out value located in register c
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn output(&self, instruction: Instruction) {
        
        let c = instruction.c.unwrap() as usize;
        let value = self.registers.get_reg_val(c);
        
        if value > 255{
            panic!("Value not within 0 and 255");
        }
        print!("{}", char::from_u32(value).unwrap());
    }

    /// waits for input and loads the given input into register c
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn input(&mut self, instruction: Instruction) {
        let c = instruction.c.unwrap() as usize;

        match stdin().bytes().next().unwrap() { 
            Ok(value) if value as char == '\n' => self.registers.set_reg_val(c, std::u32::MAX),
            Ok(value) if value as char != '\n' => self.registers.set_reg_val(c, value as u32),
            Ok(_) => panic!("Error in input"),
            Err(_) => panic!("Error in input")
        }
    }

    /// loads the program
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn loadprogram(&mut self, instruction: Instruction) -> usize {
        let b = instruction.b.unwrap() as usize;
        let c = instruction.c.unwrap() as usize;

        if self.registers.get_reg_val(b) != 0 {
            self.segment.load(self.registers.get_reg_val(b) as usize);
        }

        self.registers.get_reg_val(c) as usize
    }

    /// loads the value into register a
    ///
    /// # Arguments:
    /// * 'instruction' holds 5 different variables (opcode: <Opcode>, a: <u32>, b: Option<u32>, c: Option<u32>, and value: Option<u32>)
    pub fn loadvalue(&mut self, instruction: Instruction) {
        let a = instruction.a as usize;
        let value = instruction.value.unwrap();

        self.registers.set_reg_val(a, value);
    }
}