Noah Santagata // Isabella Martinez

We have gone to Connor/Isaacs's TA hours several times throughout the development of our code. They helped us with using CLAP, the timer to benchmark our functions, and how to use RgbImages. Additionally, we both have contributed to this code in the presence of one another whether in person or over discord. For online resources, we heavily used https://www.rust-lang.org/ to help us understand how to use the data structures such as our timer, the Rgb image crate, as well as other implemented functions and methods. 

What has been implemented correctly:
90 row major rotation
90 col major rotation
180 row major rotation
180 col major rotation
270 row major rotation
270 col major rotation
0 row major rotation
0 col major rotation
Transpose row major
Transpose col major
Flip horizontal row major
Flip horizontal col major
Flip vertical row major
Flip vertical col major
A timer to benchmark 90 and 180 rotations
We believe that we have implemented everything correctly

– Document the architecture of your solutions.
In our main.rs, we include handling CLAP. This allows us to parse through what the input line commands were and call the correct function accordingly. In our main function, we create an array2 called original_image which natively stores data in row major order. This takes in the input file/standard input’s dimensions as well as its values. Then we initialize an empty single vector that will hold our new transformation orders. We have another file called rotation.rs which holds our rotation and writing functions. We have two central if statements that first check to see what kind of iteration is selected. This is to avoid making two row and col iter functions for each transformation. Once we know the iteration type, we can just send in that iterated-through vector to the function. From here, in both row and col we check which transformations were supplied, such as flip, transpose, or rotate. We have a match statement for rotate since this statement took less lines than the classic if/else. From here, the individual functions would be called. For example, if the input was:

f.ppm –row-major rotate 90 f.ppm > output.ppm

Then our code would intake the image within the given major format (while it can be row or column wise, we are using row for this example) and then have it be rotated clockwise 90 degrees. We then include the filename that we are intaking from, as well as the output file which our information will go to afterwards.

Our invariants include:
Our iter_row_major will always visit the first element in the first row, followed by the second
element in the first row, until all the elements in the first row have been visited. This is repeated
for all the rows until the end of the elements.
Our iter_col_major will always visit the first element within the first column, followed by the
first element within the second column, until each and every column has been visited. This is a
repeated action until the end of the elements is met.
For 90 degree rotations, any pixel originally located at coordinates (i,j) will be placed at its new
coordinates at (height − j − 1, i).
Our 90 degree row rotations will be accessed/loaded by row major order using iter_row_major
and written to new storage. Similarly, 90 degree col rotations will be accessed/loaded by col
major order using iter_col_major and written to new storage.
For 180 degree rotations, any pixel originally located at coordinates (i,j) becomes the new set of
coordinates positioned at (width − i − 1, height − j − 1).
Our 180 degree row rotations will be accessed/loaded by row major order using iter_row_major
and written to new storage. Similarly, 180 degree col rotations will be accessed/loaded by col
major order using iter_col_major and written to new storage.
For every pixel that is loaded/read, the next step is storing its new position in the new vector to
load into the new Array2

~~~~~~~~~~~~~~~~~~~~~~ PART C ~~~~~~~~~~~~~~~~~~~~~~~

                 | Row-major access | Col-Major Access|
*******************************************************
|90-deg rotation |     3.47ms       |     3.97ms      |
*******************************************************
|180-deg rotation|     2.98ms       |     4.11ms      |
*******************************************************

According to the numbers recorded, this is the actual ranking of speed:
1st fastest: 180 row-major
2nd: 90 row-major
3rd: 90 col-major
4th: 180 col Major
These numbers were obtained after running each command multiple times using the test image “howth.ppm” These estimates did not match our initial estimates. Our initial estimates had a speed ranking(fastest to slowest) of: 180 Row-Major, 90 row_major, 180 col-major, and finally 90 col-major.

We were correct in predicting that Row-Major 180 rotation was the fastest since the native storage type of our Array2 is stored in row major order. This means that almost every load will be a hit and almost every store will be consequently hit. More specifically, the loading would miss the very first pixel in each row and then hit the rest of it(until the cache runs out of space, but then it’s one additional miss for every new cache line). When storing, it is very similar to the load since it will only miss the first pixel but the succeeding ones will be all hits. This method is efficient in both loading and storing. 

Next is Row-Major 90 Rotation. This type of iteration and rotation would have a high hit rate, hitting almost everything when loading since it would be loaded in row major order, however when storing, it would almost always be a miss since it is being stored at a new column every time, meaning there is bad spatial locality. 

Our next ranking is Col-Major 90. This has the opposite problem than Row-Major 90 since it has a low hit rate, but high store rate. It would not be surprising if on another average of speeds, these two rankings might swap since they have roughly the same speed. 

Lastly is Col-Major 180 which took the longest time to complete. This major iteration had the problem of missing all loads, as well as stores too. This method is the least efficient to use when dealing with an image transformation.

Hours spent:
We have spent approximately 25 hours completing this assignment.
