use csc411_image::{Read, RgbImage, Rgb};
pub use array2::Array2;
use clap::Parser;
use crate::rotation::{rot_90, rot_180, rot_0, rot_270, transpose_func,flip_hor, flip_vert};
mod rotation;
use std::time::Instant;

#[derive(Parser, Debug)]
#[clap(author, version, about, long_about = None)]

struct Args {
    // Flip
    #[clap(long = "flip", required = false)]
    flip: Option<String>,
    //  Transpose
    #[clap(long = "transpose")]
    transpose: bool,
    // Rotation
    #[clap(short = 'r', long = "rotate")]
    rotate: Option<u32>,
    // Col Major Type
    #[clap(long = "col-major")]
    col_major: bool,
    // Row Major Type
    #[clap(long = "row-major")]
    row_major: bool,
    // File Input
    #[clap()]
    file_given: Option<String>,

}

fn main() {
    let args = Args::parse();
    let rotate = args.rotate;
    let col_major = args.col_major;
    let row_major = args.row_major;
    let flip = args.flip;
    let transpose = args.transpose;

    let input = args.file_given;
    let puzzle = RgbImage::read(input.as_deref()).unwrap();

    
    let mut v = Vec::new();

    for elements in puzzle.pixels{
        v.push((elements.red as usize, elements.green as usize, elements.blue as usize));
    }

    let original_image = Array2::new_array(v, puzzle.width as usize, puzzle.height as usize);
    
    let _timer_boy = Instant::now();
    
    
    let updated_vec:Vec<csc411_image::Rgb> = vec![Rgb{red:0, green:0, blue:0}; original_image.width * original_image.height];
    if row_major == true{
        // Invariant:
        // Our iter_row_major will always visit the first element in the first row, followed by the second
        // element in the first row, until all the elements in the first row have been visited. This is repeated
        // all the rows until the end of the elements.
        // For every pixel that is loaded/read, the next step is storing its new position in the new vector to
        // load into the new Array2.

        let row_iter:  Vec<_> = original_image.iter_row_major().collect();
        if flip == Some("horizontal".to_string()){
            flip_hor(&original_image, puzzle.denominator as u16, row_iter, updated_vec);
        } 
        else if flip == Some("vertical".to_string()){
            flip_vert(&original_image, puzzle.denominator as u16, row_iter, updated_vec);
        }
        else if transpose{
            transpose_func(&original_image, puzzle.denominator as u16, row_iter, updated_vec);
        }
        else{
            match rotate{
            Some(0) => rot_0(&original_image, puzzle.denominator as u16, row_iter, updated_vec),
            // Invariant:
            // Our 90 degree row rotations will be accessed/loaded by row major order using iter_row_major
            // and written to new storage. 
            Some(90) => rot_90(&original_image, puzzle.denominator as u16, row_iter, updated_vec, _timer_boy),
            Some(180) => rot_180(&original_image, puzzle.denominator as u16, row_iter, updated_vec, _timer_boy),
            Some(270) => rot_270(&original_image, puzzle.denominator as u16, row_iter, updated_vec),
            None => todo!(),
            _ => todo!(),
            }
        }
    }
    else if col_major == true{
        // Invariant:
        // Our iter_col_major will always visit the first element within the first column, followed by the
        // first element within the second column, until each and every column has been visited. This is a
        // repeated action until the end of the elements is met.
        let col_iter:  Vec<_> = original_image.iter_col_major().collect();
        if flip == Some("horizontal".to_string()){
            flip_hor(&original_image, puzzle.denominator as u16, col_iter, updated_vec);
        } 
        else if flip == Some("vertical".to_string()){
            flip_vert(&original_image, puzzle.denominator as u16, col_iter, updated_vec);
        }
        else if transpose{
            transpose_func(&original_image, puzzle.denominator as u16, col_iter, updated_vec);
        }
        else{
            match rotate{
            Some(0) => rot_0(&original_image, puzzle.denominator as u16, col_iter, updated_vec),
            // Invariant:
            // 90 degree col rotations will be accessed/loaded by col
            // major order using iter_col_major and written to new storage.
            Some(90) => rot_90(&original_image, puzzle.denominator as u16, col_iter, updated_vec, _timer_boy),
            Some(180) => rot_180(&original_image, puzzle.denominator as u16, col_iter, updated_vec, _timer_boy),
            Some(270) => rot_270(&original_image, puzzle.denominator as u16, col_iter, updated_vec),
            None => todo!(),
            _ => todo!(),
            }
        }
    }

}