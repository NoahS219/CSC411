use array2::Array2;
use csc411_image::{Write, RgbImage, Rgb};
use std::time::Instant;

#[allow(dead_code)]
#[allow(unused_must_use)]

pub fn write_result_same_dim(original_image: &Array2<(usize,usize,usize)>, updated_vec: Vec<csc411_image::Rgb>, denominator: u16){
    let write = RgbImage{
        width: original_image.width as u32,
        height: original_image.height as u32,
        denominator: denominator,
        pixels: updated_vec,
    };

    write.write(None);
}

#[allow(dead_code)]
#[allow(unused_must_use)]

pub fn write_result_diff_dim(original_image: &Array2<(usize,usize,usize)>, updated_vec: Vec<csc411_image::Rgb>, denominator: u16){
    let write = RgbImage{
        width: original_image.height as u32,
        height: original_image.width as u32,
        denominator: denominator,
        pixels: updated_vec,
    };

    write.write(None);
}

#[allow(dead_code)]
#[allow(unused_must_use)]
pub fn rot_0(original_image: &Array2<(usize,usize,usize)>, denominator: u16, major_iter: Vec<(usize, usize, &(usize, usize, usize))>, mut updated_vec:Vec<csc411_image::Rgb>){
    for elements in major_iter{
        let rowlad = elements.0;
        let collad = elements.1;
        updated_vec[original_image.width * collad + rowlad] = Rgb{red:elements.2.0 as u16, green:elements.2.1 as u16, blue:elements.2.2 as u16};
    }
    write_result_same_dim(&original_image, updated_vec, denominator);
}

#[allow(dead_code)]
#[allow(unused_must_use)]

// Invariant:
// For 90 degree rotations, any pixel originally located at coordinates (i,j) will be placed at its new
// coordinates at (height − j − 1, i).
pub fn rot_90(original_image: &Array2<(usize,usize,usize)>, denominator: u16, major_iter: Vec<(usize, usize, &(usize, usize, usize))>, mut updated_vec:Vec<csc411_image::Rgb>, _timer_boy: Instant){
    for elements in major_iter{
        let rowlad = original_image.height - elements.1 - 1;
        let collad = elements.0;
        updated_vec[original_image.height * collad + rowlad] = Rgb{red:elements.2.0 as u16, green:elements.2.1 as u16, blue:elements.2.2 as u16};
    }

    write_result_diff_dim(&original_image, updated_vec, denominator);
    //println!("This is 90: {:.2?}", _timer_boy.elapsed());
}


#[allow(dead_code)]
#[allow(unused_must_use)]

// Invariant:
// For 180 degree rotations, any pixel originally located at coordinates (i,j) becomes the new set of
// coordinates positioned at (width − i − 1, height − j − 1).

pub fn rot_180(original_image: &Array2<(usize,usize,usize)>, denominator: u16, major_iter: Vec<(usize, usize, &(usize, usize, usize))>, mut updated_vec:Vec<csc411_image::Rgb>,  _timer_boy: Instant){
    for elements in major_iter{
        let rowlad = original_image.width - elements.0 - 1;
        let collad = original_image.height - elements.1 -1;
        
        updated_vec[original_image.width * collad + rowlad] = Rgb{red:elements.2.0 as u16, green:elements.2.1 as u16, blue:elements.2.2 as u16};
    }

    write_result_same_dim(&original_image, updated_vec, denominator);
    //println!("This is 180: {:.2?}", _timer_boy.elapsed());
}

#[allow(dead_code)]
#[allow(unused_must_use)]
pub fn rot_270(original_image: &Array2<(usize,usize,usize)>, denominator: u16, major_iter: Vec<(usize, usize, &(usize, usize, usize))>, mut updated_vec:Vec<csc411_image::Rgb>){
    for elements in major_iter{
        let rowlad = elements.1;
        let collad = original_image.width - elements.0 - 1;
        
        updated_vec[original_image.height * collad + rowlad] = Rgb{red:elements.2.0 as u16, green:elements.2.1 as u16, blue:elements.2.2 as u16};
    }

    write_result_diff_dim(&original_image, updated_vec, denominator);
}


#[allow(dead_code)]
#[allow(unused_must_use)]
pub fn flip_hor(original_image: &Array2<(usize,usize,usize)>, denominator: u16, major_iter: Vec<(usize, usize, &(usize, usize, usize))>, mut updated_vec:Vec<csc411_image::Rgb>){
    for elements in major_iter{
        let rowlad = original_image.width - elements.0 - 1;
        let collad = elements.1;
        
        updated_vec[original_image.width * collad + rowlad] = Rgb{red:elements.2.0 as u16, green:elements.2.1 as u16, blue:elements.2.2 as u16};
    }

    write_result_same_dim(&original_image, updated_vec, denominator);
}

#[allow(dead_code)]
#[allow(unused_must_use)]
pub fn flip_vert(original_image: &Array2<(usize,usize,usize)>, denominator: u16, major_iter: Vec<(usize, usize, &(usize, usize, usize))>, mut updated_vec:Vec<csc411_image::Rgb>){
    for elements in major_iter{
        let rowlad = elements.0;
        let collad = original_image.height - elements.1 - 1;
        
        updated_vec[original_image.width * collad + rowlad] = Rgb{red:elements.2.0 as u16, green:elements.2.1 as u16, blue:elements.2.2 as u16};
    }

    write_result_same_dim(&original_image, updated_vec, denominator);
}

#[allow(dead_code)]
#[allow(unused_must_use)]
pub fn transpose_func(original_image: &Array2<(usize,usize,usize)>, denominator: u16, major_iter: Vec<(usize, usize, &(usize, usize, usize))>, mut updated_vec:Vec<csc411_image::Rgb>){
    for elements in major_iter{
        let rowlad = elements.1;
        let collad = elements.0;
        
        updated_vec[original_image.height * collad + rowlad] = Rgb{red:elements.2.0 as u16, green:elements.2.1 as u16, blue:elements.2.2 as u16};
    }

    write_result_diff_dim(&original_image, updated_vec, denominator);
}


